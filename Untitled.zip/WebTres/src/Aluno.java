
public class Aluno extends Pessoa implements UsuarioBiblioteca {

	@Override
	public void retirarLivro(String nomeL) {
		if (this.isPermissaoBiblioteca()) {
			System.out.println("O livro " + nomeL + " foi retirado com sucesso!");
		}
		else
			System.out.println("ERRO! O usuário " + this.getNomeUsuario() + " está bloqueado para este tipo de transação.");
	
		System.exit(0);
	}

	@Override
	public void bloqueiaId(int idUs) {
		this.setPermissaoBiblioteca(false);
	}

	@Override
	public void liberaId(int idUs) {
		this.setPermissaoBiblioteca(true);
	}
	
}
