import java.util.Scanner;

public class Biblioteca {

	public String entrada;
	public Aluno a;
	Scanner in = new Scanner(System.in);
	
	public void criaAluno() {
		
		a = new Aluno();
		System.out.println("Digite o nome do Aluno: ");
		entrada = in.nextLine();
		a.setNomeUsuario(entrada);
		a.setTipoUsuario("Aluno");
		a.setPermissaoBiblioteca(true);
		a.setIdUsuario(1000 + 1);
		System.out.println("Aluno criado com sucesso! Sua ID é: " + a.getIdUsuario());
	}
	
	public void selecaoLivro() {
		
		System.out.println("Digite o nome do livro: ");
		entrada = in.nextLine();
		a.retirarLivro(entrada);
	}
	
	public static void main (String [] args) {
				
		Biblioteca b = new Biblioteca();
		
		b.criaAluno();
		b.selecaoLivro();
	}
}
