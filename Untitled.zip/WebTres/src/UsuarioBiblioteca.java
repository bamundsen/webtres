
public interface UsuarioBiblioteca {

	public void retirarLivro(String nomeL);
	
	public void bloqueiaId(int idUs);
	
	public void liberaId(int idUs);
}
