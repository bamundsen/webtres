
public abstract class Pessoa {

	private String nomeUsuario;
	private String tipoUsuario;
	private int idUsuario;
	private boolean permissaoBiblioteca;
	
	public boolean isPermissaoBiblioteca() {
		return permissaoBiblioteca;
	}
	public void setPermissaoBiblioteca(boolean permissaoBiblioteca) {
		this.permissaoBiblioteca = permissaoBiblioteca;
	}
	public String getNomeUsuario() {
		return nomeUsuario;
	}
	public void setNomeUsuario(String nomeUsuario) {
		this.nomeUsuario = nomeUsuario;
	}
	public String getTipoUsuario() {
		return tipoUsuario;
	}
	public void setTipoUsuario(String tipoUsuario) {
		this.tipoUsuario = tipoUsuario;
	}
	public int getIdUsuario() {
		return idUsuario;
	}
	public void setIdUsuario(int idUsuario) {
		this.idUsuario = idUsuario;
	}
}
